package tn.neopolis.ApplicationManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
